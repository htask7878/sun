package com.example.sun;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
