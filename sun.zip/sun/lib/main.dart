import 'package:flutter/material.dart';
import 'package:sun/sun.dart';

void main() {
  runApp(MaterialApp(home: sun(),)
  );
}